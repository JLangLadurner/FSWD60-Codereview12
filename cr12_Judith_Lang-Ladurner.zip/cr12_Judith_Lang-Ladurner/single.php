<?php get_header(); ?>
 
  <div class="row ">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php the_post_thumbnail() ?>      
      <div class="col-lg-10">
             
             <span class="headSingle"><h1><span class="headSingle"><?php the_title(); ?></span></h1>
           
             <div class="col-lg-10">
                <?php the_content(); ?>
             </div>
        </div>
         
            <?php
          if(is_active_sidebar('sidebar')):
         dynamic_sidebar('sidebar');
         endif;  
          ?>
          
         </div><!-- row - blogpost and sidebar-->

        <div class="row">
        <div id="comments" class="col-lg-5">
          
        <!-- adds comments to the single.php - look in functions.php for comments set up-->
        <?php 
        if ( comments_open() || get_comments_number() ) :
        comments_template();
        endif;
       ?>
       </div>
        </div><!-- row - comments-->
         
        <?php endwhile; endif; ?>
  
    

<?php get_footer(); ?> 
 
