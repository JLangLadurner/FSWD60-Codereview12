<?php get_header(); ?>


<div class="row">
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>  <!-- loop through the posts -->
  <div id="jumbomarg" class="col-md-4">
    <h2 class="blog-post-title">
     <a href="<?php the_permalink(); ?>"> <!--retrieves URL for the permalink-->
      <?php the_title(); ?> </h2></a><!--retrieves blog title-->
      <p class="blog-post-meta">Date: <?php the_time('F j, Y g:i a'); ?> <br>Category: <?php foreach(get_the_category() as $category){
        echo '<a href="'.get_category_link($category->cat_ID).'">';
        echo $category->cat_name."</a>"; 
      }
      ?></p><!--retrieves date blog entry was created-->
      <?php the_content(); ?>
      <!-- <?php the_excerpt(); ?> --><!--retrieves content/ print the content of the blog post -->

      <p>Author: <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p><!--retrieves author of blog entry-->
    </div>
  <?php endwhile;  endif;?>
</div>
<!-- container close div missing if needed
-->  

<?php get_footer(); ?>

